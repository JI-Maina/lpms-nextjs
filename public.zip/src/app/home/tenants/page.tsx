const TenantsHomePage = () => {
  return <div>TenantsHomePage</div>;
};

export default TenantsHomePage;
