const PropertiesBanner = () => {
  return (
    <div className="h-36 bg-property bg-cover bg-center bg-no-repeat bg-opacity-5 relative"></div>
  );
};

export default PropertiesBanner;
